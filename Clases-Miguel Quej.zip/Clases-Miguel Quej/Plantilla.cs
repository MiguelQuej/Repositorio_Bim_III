﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public class Plantilla
    {
        string nombre = "Miguel";
        string apellido;
        string identificación;

        public Plantilla(string n, string a, string i)
            {
            nombre = n;
            apellido = a;
            identificación = i;

            }
        public void nombrar ()
        {
            System.Windows.Forms.MessageBox.Show("El nombre es: "+nombre);
            System.Windows.Forms.MessageBox.Show("El apellido es: " + apellido);
            System.Windows.Forms.MessageBox.Show("El Número de identificación es: " + identificación);

        }
        public void mostrar()
        {

        }
    }
}
