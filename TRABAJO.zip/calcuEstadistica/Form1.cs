﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace calcuEstadistica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //caputrar paosicion y tama;o antes de maximizar pra restaurar
        int lx, ly;
        int ancho, alto;

        private void btnMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pnlArrastrar_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void pnlArrastrar_MouseMove(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        //MeTODO PARA ARRASTRAR EL FORMULARIO
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private void iconButton1_Click(object sender, EventArgs e)
        {
            // Obtener los números del TextBox
            string input = textBoxNumeros.Text;
            int[] numeros = input.Split(',').Select(x => int.Parse(x.Trim())).ToArray();


            // Validar que no se hayan ingresado ceros
            if (numeros.Contains(0))
            {
                MessageBox.Show("Error: Se ingresó al menos un cero en el conjunto de datos.");
                return;
            }

            // Calcular la moda
            int moda = CalcularModa(numeros);

            // Calcular la media
            double media = CalcularMedia(numeros);

            // Calcular la mediana
            double mediana = CalcularMediana(numeros);

            lblM.Text = moda.ToString();
            lblMed.Text = media.ToString("f2");
            lblMedianas.Text = mediana.ToString();



        }


        static int CalcularModa(int[] numeros)
        {
            Dictionary<int, int> conteo = new Dictionary<int, int>();

            foreach (int numero in numeros)
            {
                if (conteo.ContainsKey(numero))
                {
                    conteo[numero]++;
                }
                else
                {
                    conteo[numero] = 1;
                }
            }

            int maximoConteo = conteo.Values.Max();
            int moda = conteo.FirstOrDefault(x => x.Value == maximoConteo).Key;

            return moda;
        }

        static double CalcularMediana(int[] numeros)
        {
            Array.Sort(numeros);

            int n = numeros.Length;
            double mediana;

            if (n % 2 == 0)
            {
                int indice1 = n / 2 - 1;
                int indice2 = n / 2;
                mediana = (numeros[indice1] + numeros[indice2]) / 2.0;
            }
            else
            {
                int indice = n / 2;
                mediana = numeros[indice];
            }

            return mediana;
        }

        static double CalcularMedia(int[] numeros)
        {
            double suma = 0;

            foreach (int numero in numeros)
            {
                suma += numero;
            }

            double media = suma / numeros.Length;

            return media;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            string input = txtValores.Text;

            // Dividir los valores ingresados y convertirlos a números
            double[] valores = input.Split(',')
                                    .Select(x => double.Parse(x.Trim()))
                                    .ToArray();

            // Crear una instancia de la clase Estadisticas
            Estadisticas estadisticas = new Estadisticas(valores);

            // Calcular y mostrar el rango y la desviación estándar
            lblRango.Text = "" + estadisticas.CalcularRango();
            lblDesviacionEstandar.Text = "" + estadisticas.CalcularDesviacionEstandar();

        }

        private void btnMaximizar_Click(object sender, EventArgs e)
        {
            lx = this.Location.X;
            ly = this.Location.Y;
            ancho = this.Size.Width;
            alto = this.Size.Height;
            btnMaximizar.Visible = false;
            btnNormal.Visible = true;
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;//Obtener tamanio de pantalla
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnNormal_Click(object sender, EventArgs e)
        {
            btnMaximizar.Visible = true;
            btnNormal.Visible = false;
            this.Size = new Size(ancho, alto);
            this.Location = new Point(lx, ly);
        }
        public class Estadisticas
        {
            private double[] datos;

            public Estadisticas(double[] datos)
            {
                this.datos = datos;
            }

            public double CalcularRango()
            {
                double maximo = datos.Max();
                double minimo = datos.Min();
                double rango = maximo - minimo;
                return rango;
            }

            public double CalcularDesviacionEstandar()
            {
                double media = datos.Average();
                double sumaCuadrados = datos.Sum(x => Math.Pow(x - media, 2));
                double varianza = sumaCuadrados / datos.Length;
                double desviacionEstandar = Math.Sqrt(varianza);
                return desviacionEstandar;
            }
        }
    }
}



