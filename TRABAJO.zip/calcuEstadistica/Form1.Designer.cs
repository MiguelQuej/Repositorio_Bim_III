﻿
namespace calcuEstadistica
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblDesviacionEstandar = new System.Windows.Forms.Label();
            this.lblRango = new System.Windows.Forms.Label();
            this.lb_desviacion = new System.Windows.Forms.Label();
            this.lb_rango = new System.Windows.Forms.Label();
            this.lblMedianas = new System.Windows.Forms.Label();
            this.lblMed = new System.Windows.Forms.Label();
            this.lblM = new System.Windows.Forms.Label();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.lblMedia = new System.Windows.Forms.Label();
            this.lblMediana = new System.Windows.Forms.Label();
            this.lblModa = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.textBoxNumeros = new System.Windows.Forms.TextBox();
            this.pnlArrastrar = new System.Windows.Forms.Panel();
            this.btnNormal = new System.Windows.Forms.Button();
            this.btnMaximizar = new System.Windows.Forms.Button();
            this.btnMinimizar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnCalcular = new FontAwesome.Sharp.IconButton();
            this.txtValores = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.pnlArrastrar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(74)))), ((int)(((byte)(110)))), ((int)(((byte)(176)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtValores);
            this.panel1.Controls.Add(this.btnCalcular);
            this.panel1.Controls.Add(this.lblDesviacionEstandar);
            this.panel1.Controls.Add(this.lblRango);
            this.panel1.Controls.Add(this.lb_desviacion);
            this.panel1.Controls.Add(this.lb_rango);
            this.panel1.Controls.Add(this.lblMedianas);
            this.panel1.Controls.Add(this.lblMed);
            this.panel1.Controls.Add(this.lblM);
            this.panel1.Controls.Add(this.iconButton1);
            this.panel1.Controls.Add(this.lblMedia);
            this.panel1.Controls.Add(this.lblMediana);
            this.panel1.Controls.Add(this.lblModa);
            this.panel1.Controls.Add(this.lblTitulo);
            this.panel1.Controls.Add(this.textBoxNumeros);
            this.panel1.Controls.Add(this.pnlArrastrar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1067, 554);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblDesviacionEstandar
            // 
            this.lblDesviacionEstandar.AutoSize = true;
            this.lblDesviacionEstandar.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesviacionEstandar.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblDesviacionEstandar.Location = new System.Drawing.Point(344, 340);
            this.lblDesviacionEstandar.Name = "lblDesviacionEstandar";
            this.lblDesviacionEstandar.Size = new System.Drawing.Size(0, 22);
            this.lblDesviacionEstandar.TabIndex = 13;
            // 
            // lblRango
            // 
            this.lblRango.AutoSize = true;
            this.lblRango.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRango.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblRango.Location = new System.Drawing.Point(344, 305);
            this.lblRango.Name = "lblRango";
            this.lblRango.Size = new System.Drawing.Size(0, 22);
            this.lblRango.TabIndex = 12;
            // 
            // lb_desviacion
            // 
            this.lb_desviacion.AutoSize = true;
            this.lb_desviacion.Font = new System.Drawing.Font("Tempus Sans ITC", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_desviacion.ForeColor = System.Drawing.Color.Gainsboro;
            this.lb_desviacion.Location = new System.Drawing.Point(52, 328);
            this.lb_desviacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_desviacion.Name = "lb_desviacion";
            this.lb_desviacion.Size = new System.Drawing.Size(255, 35);
            this.lb_desviacion.TabIndex = 11;
            this.lb_desviacion.Text = "Desviacion Estandar";
            // 
            // lb_rango
            // 
            this.lb_rango.AutoSize = true;
            this.lb_rango.Font = new System.Drawing.Font("Tempus Sans ITC", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_rango.ForeColor = System.Drawing.Color.Gainsboro;
            this.lb_rango.Location = new System.Drawing.Point(52, 293);
            this.lb_rango.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_rango.Name = "lb_rango";
            this.lb_rango.Size = new System.Drawing.Size(93, 35);
            this.lb_rango.TabIndex = 10;
            this.lb_rango.Text = "Rango";
            // 
            // lblMedianas
            // 
            this.lblMedianas.AutoSize = true;
            this.lblMedianas.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedianas.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblMedianas.Location = new System.Drawing.Point(343, 266);
            this.lblMedianas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMedianas.Name = "lblMedianas";
            this.lblMedianas.Size = new System.Drawing.Size(0, 22);
            this.lblMedianas.TabIndex = 9;
            // 
            // lblMed
            // 
            this.lblMed.AutoSize = true;
            this.lblMed.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMed.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblMed.Location = new System.Drawing.Point(343, 237);
            this.lblMed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMed.Name = "lblMed";
            this.lblMed.Size = new System.Drawing.Size(0, 22);
            this.lblMed.TabIndex = 8;
            // 
            // lblM
            // 
            this.lblM.AutoSize = true;
            this.lblM.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblM.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblM.Location = new System.Drawing.Point(343, 201);
            this.lblM.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblM.Name = "lblM";
            this.lblM.Size = new System.Drawing.Size(0, 22);
            this.lblM.TabIndex = 7;
            // 
            // iconButton1
            // 
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconButton1.IconColor = System.Drawing.Color.Black;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.Location = new System.Drawing.Point(553, 86);
            this.iconButton1.Margin = new System.Windows.Forms.Padding(4);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(100, 28);
            this.iconButton1.TabIndex = 6;
            this.iconButton1.Text = "Resolver";
            this.iconButton1.UseVisualStyleBackColor = true;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // lblMedia
            // 
            this.lblMedia.AutoSize = true;
            this.lblMedia.Font = new System.Drawing.Font("Tempus Sans ITC", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedia.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblMedia.Location = new System.Drawing.Point(52, 224);
            this.lblMedia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMedia.Name = "lblMedia";
            this.lblMedia.Size = new System.Drawing.Size(89, 35);
            this.lblMedia.TabIndex = 5;
            this.lblMedia.Text = "Media";
            // 
            // lblMediana
            // 
            this.lblMediana.AutoSize = true;
            this.lblMediana.Font = new System.Drawing.Font("Tempus Sans ITC", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMediana.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblMediana.Location = new System.Drawing.Point(52, 258);
            this.lblMediana.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMediana.Name = "lblMediana";
            this.lblMediana.Size = new System.Drawing.Size(118, 35);
            this.lblMediana.TabIndex = 4;
            this.lblMediana.Text = "Mediana";
            // 
            // lblModa
            // 
            this.lblModa.AutoSize = true;
            this.lblModa.Font = new System.Drawing.Font("Tempus Sans ITC", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModa.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblModa.Location = new System.Drawing.Point(52, 188);
            this.lblModa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblModa.Name = "lblModa";
            this.lblModa.Size = new System.Drawing.Size(85, 35);
            this.lblModa.TabIndex = 3;
            this.lblModa.Text = "Moda";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.Gainsboro;
            this.lblTitulo.Location = new System.Drawing.Point(30, 56);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(182, 26);
            this.lblTitulo.TabIndex = 2;
            this.lblTitulo.Text = "Ingrese los valores";
            // 
            // textBoxNumeros
            // 
            this.textBoxNumeros.Location = new System.Drawing.Point(35, 86);
            this.textBoxNumeros.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNumeros.Name = "textBoxNumeros";
            this.textBoxNumeros.Size = new System.Drawing.Size(437, 22);
            this.textBoxNumeros.TabIndex = 1;
            // 
            // pnlArrastrar
            // 
            this.pnlArrastrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(76)))), ((int)(((byte)(95)))));
            this.pnlArrastrar.Controls.Add(this.btnNormal);
            this.pnlArrastrar.Controls.Add(this.btnMaximizar);
            this.pnlArrastrar.Controls.Add(this.btnMinimizar);
            this.pnlArrastrar.Controls.Add(this.button1);
            this.pnlArrastrar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlArrastrar.Location = new System.Drawing.Point(0, 0);
            this.pnlArrastrar.Margin = new System.Windows.Forms.Padding(4);
            this.pnlArrastrar.Name = "pnlArrastrar";
            this.pnlArrastrar.Size = new System.Drawing.Size(1067, 52);
            this.pnlArrastrar.TabIndex = 0;
            this.pnlArrastrar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlArrastrar_MouseDown);
            this.pnlArrastrar.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlArrastrar_MouseMove);
            // 
            // btnNormal
            // 
            this.btnNormal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNormal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(76)))), ((int)(((byte)(95)))));
            this.btnNormal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNormal.BackgroundImage")));
            this.btnNormal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnNormal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNormal.FlatAppearance.BorderSize = 0;
            this.btnNormal.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnNormal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNormal.Location = new System.Drawing.Point(976, 15);
            this.btnNormal.Margin = new System.Windows.Forms.Padding(4);
            this.btnNormal.Name = "btnNormal";
            this.btnNormal.Size = new System.Drawing.Size(33, 31);
            this.btnNormal.TabIndex = 11;
            this.btnNormal.UseVisualStyleBackColor = false;
            this.btnNormal.Visible = false;
            this.btnNormal.Click += new System.EventHandler(this.btnNormal_Click);
            // 
            // btnMaximizar
            // 
            this.btnMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(76)))), ((int)(((byte)(95)))));
            this.btnMaximizar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMaximizar.BackgroundImage")));
            this.btnMaximizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnMaximizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaximizar.FlatAppearance.BorderSize = 0;
            this.btnMaximizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnMaximizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximizar.Location = new System.Drawing.Point(976, 15);
            this.btnMaximizar.Margin = new System.Windows.Forms.Padding(4);
            this.btnMaximizar.Name = "btnMaximizar";
            this.btnMaximizar.Size = new System.Drawing.Size(33, 31);
            this.btnMaximizar.TabIndex = 10;
            this.btnMaximizar.UseVisualStyleBackColor = false;
            this.btnMaximizar.Click += new System.EventHandler(this.btnMaximizar_Click);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(76)))), ((int)(((byte)(95)))));
            this.btnMinimizar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMinimizar.BackgroundImage")));
            this.btnMinimizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimizar.FlatAppearance.BorderSize = 0;
            this.btnMinimizar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btnMinimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimizar.Location = new System.Drawing.Point(935, 15);
            this.btnMinimizar.Margin = new System.Windows.Forms.Padding(4);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(33, 31);
            this.btnMinimizar.TabIndex = 9;
            this.btnMinimizar.UseVisualStyleBackColor = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(76)))), ((int)(((byte)(95)))));
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(1017, 15);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(33, 31);
            this.button1.TabIndex = 8;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnCalcular.IconColor = System.Drawing.Color.Black;
            this.btnCalcular.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnCalcular.Location = new System.Drawing.Point(553, 147);
            this.btnCalcular.Margin = new System.Windows.Forms.Padding(4);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(100, 28);
            this.btnCalcular.TabIndex = 14;
            this.btnCalcular.Text = "Resolver";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtValores
            // 
            this.txtValores.Location = new System.Drawing.Point(35, 150);
            this.txtValores.Margin = new System.Windows.Forms.Padding(4);
            this.txtValores.Name = "txtValores";
            this.txtValores.Size = new System.Drawing.Size(437, 22);
            this.txtValores.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tempus Sans ITC", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(30, 118);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(388, 26);
            this.label1.TabIndex = 16;
            this.label1.Text = "Ingrese los valores (Rango y Desviacion)";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlArrastrar.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.TextBox textBoxNumeros;
        private System.Windows.Forms.Panel pnlArrastrar;
        private System.Windows.Forms.Button btnNormal;
        private System.Windows.Forms.Button btnMaximizar;
        private System.Windows.Forms.Button btnMinimizar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblMedia;
        private System.Windows.Forms.Label lblMediana;
        private System.Windows.Forms.Label lblModa;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.Label lblMedianas;
        private System.Windows.Forms.Label lblMed;
        private System.Windows.Forms.Label lblM;
        private System.Windows.Forms.Label lblDesviacionEstandar;
        private System.Windows.Forms.Label lblRango;
        private System.Windows.Forms.Label lb_desviacion;
        private System.Windows.Forms.Label lb_rango;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtValores;
        private FontAwesome.Sharp.IconButton btnCalcular;
    }
}

